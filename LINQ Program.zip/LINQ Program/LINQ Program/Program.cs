﻿
using System;
using System.Collections.Generic;
using System.Linq;

namespace LINQ_Program
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Author> AuthorList = new List<Author>();
            AuthorList.Add(new Author("Mahesh Chand", 35, "A Prorammer's Guide to ADO.NET", true, new DateTime(2003, 7, 10), "Backend program"));
            AuthorList.Add(new Author("Neel Beniwal", 18, "Graphics Development with C#", false, new DateTime(2010, 2, 22), "Backend program"));
            AuthorList.Add(new Author("Praveen Kumar", 28, "Mastering WCF", true, new DateTime(2012, 01, 01), "Backend program"));
            AuthorList.Add(new Author("Mahesh Chand", 35, "Graphics Programming with GDI+", true, new DateTime(2008, 01, 20), "Frontend program"));
            AuthorList.Add(new Author("Raj Kumar", 30, "Building Creative Systems", false, new DateTime(2011, 6, 3), "Frontend program"));

            // Displaying area of expertise

            Console.WriteLine("Area of expertise is :");
            var expertiseArea = AuthorList.Select(c=>c.areaofexpertise).Distinct();
            foreach(var area in expertiseArea)
            {
                Console.WriteLine(area);
            }

            // Displaying total number of books

            var totalBooks = AuthorList.Select(a => a.BookTitle).Count();
            Console.WriteLine("Total books are: " + totalBooks);

            // Displaying min, max and average age of the authors

            var minAge = AuthorList.Select(b => b.Age).Min();
            Console.WriteLine("Minimum age of the author is :" + minAge);

            var maxAge = AuthorList.Select(c => c.Age).Max();
            Console.WriteLine("Maximum age of the author is :" + maxAge);

            var avgAge = AuthorList.Select(a => a.Age).Average();
            Console.WriteLine("Average age of the authors is: " + avgAge);

            //Group the authors by their area of expertise and display the results. 
            var authorGroup = from author in AuthorList
                              group author by author.areaofexpertise;

            foreach(var group in authorGroup)
            {
                Console.WriteLine(group.Key + " : " + group.Count());

                // Iterating through each author of group
                foreach(var author in group)
                {
                    Console.WriteLine("Author name : " + author.Name + " , Area of expertise : " + author.areaofexpertise);
                }
            }
        }
    }

    class Author
    {


        public string Name { get; set; }

        public double Age { get; set; }

        public string BookTitle { get; set; }

        public bool IsMVP { get; set; }

        public DateTime PublishedDate { get; set; }

        public string areaofexpertise { get; set; }

        public Author(string name, short age, string title, bool mvp, DateTime pubdate, string areaofexpertise)
        {
            this.Name = name;
            this.Age = age;
            this.BookTitle = title;
            this.IsMVP = mvp;
            this.PublishedDate = pubdate;
            this.areaofexpertise = areaofexpertise;
        }


    }
}
